const winston = require('winston');
const fs = require('fs');
const path = require('path');

// Garantir que a pasta de logs exista
const logsDir = path.join(__dirname, '../../logs'); // Caminho correto com base na estrutura
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir);
}

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: path.join(logsDir, 'app.log') }),
  ],
});

module.exports = logger;
