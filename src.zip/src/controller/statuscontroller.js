const express = require('express');
const router = express.Router();
const { acessarApiCentral } = require('../services/apiCentralService'); // Caminho correto
const logger = require('../utils/logger'); // Caminho correto

/**
 * Rota POST para verificar status e realizar teste de API.
 * Corpo da requisição deve incluir: { apiLink, cnpj, token, body }
 */
router.post('/', async (req, res) => {
  const { apiLink, cnpj, token, body } = req.body;

  logger.info('Requisição recebida para verificar status da API.', { apiLink, cnpj });

  if (!apiLink || !cnpj || !token || !body) {
    logger.error('Requisição inválida. Dados faltando no corpo.');
    return res.status(400).json({ error: 'Dados incompletos. Verifique apiLink, cnpj, token e body.' });
  }

  try {
    const resultado = await acessarApiCentral(apiLink, cnpj, token, body);
    logger.info('Requisição para a API central realizada com sucesso.', resultado);

    return res.status(200).json({
      message: 'Teste de comunicação bem-sucedido.',
      data: resultado,
    });
  } catch (error) {
    logger.error('Erro durante a requisição para a API central.', { error: error.message });

    return res.status(500).json({
      error: 'Erro ao acessar a API central.',
      details: error.message,
    });
  }
});

module.exports = router;
