const { Client } = require('pg');

// Valida variáveis de ambiente
const {
  PG_HOST,
  PG_PORT,
  PG_USER,
  PG_PASSWORD,
  PG_DATABASE,
} = process.env;

if (!PG_HOST || !PG_PORT || !PG_USER || !PG_PASSWORD || !PG_DATABASE) {
  throw new Error('Variáveis de ambiente para conexão ao PostgreSQL não estão configuradas.');
}

// Configuração do cliente PostgreSQL
const client = new Client({
  host: PG_HOST,
  port: PG_PORT,
  user: PG_USER,
  password: PG_PASSWORD,
  database: PG_DATABASE,
});

/**
 * Conecta ao banco de dados
 */
async function conectarBanco() {
  try {
    await client.connect();
    console.log('Conexão com o banco de dados estabelecida com sucesso.');
  } catch (err) {
    console.error('Erro ao conectar ao banco de dados:', err.message);
    throw err;
  }
}

/**
 * Executa uma consulta no banco de dados
 * @param {string} query - SQL Query
 * @returns {object} - Resultado da consulta
 */
async function executarConsulta(query) {
  try {
    const res = await client.query(query);
    console.log('Consulta executada com sucesso:', res.rows);
    return res.rows;
  } catch (err) {
    console.error('Erro ao executar consulta no banco de dados:', err.message);
    throw err;
  }
}

/**
 * Encerra a conexão com o banco
 */
async function fecharConexao() {
  try {
    await client.end();
    console.log('Conexão com o banco encerrada.');
  } catch (err) {
    console.error('Erro ao encerrar conexão com o banco:', err.message);
  }
}

module.exports
